const timeElements = {
  days: document.getElementById("days"),
  hours: document.getElementById("hours"),
  minutes: document.getElementById("minutes"),
  seconds: document.getElementById("seconds"),
};
const mainElement = document.querySelector("main");


const countDownDate = new Date("August 15, 2025 00:00:00 GMT+0500").getTime();

const countdownInterval = setInterval(function () {
  const now = Date.now();
  const distance = countDownDate - now;

  if (distance <= 0) {
    clearInterval(countdownInterval);
    mainElement.innerHTML =
      '<h1 class="text-5xl font-bold">We are live!</h1>';
    return;
  }

  const days = Math.floor(distance / (1000 * 60 * 60 * 24));
  const hours = Math.floor(
    (distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)
  );
  const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
  const seconds = Math.floor((distance % (1000 * 60)) / 1000);

  const formatTime = (t) => (t < 10 ? `0${t}` : t);

  timeElements.days.textContent = formatTime(days);
  timeElements.hours.textContent = formatTime(hours);
  timeElements.minutes.textContent = formatTime(minutes);
  timeElements.seconds.textContent = formatTime(seconds);
}, 1000);
